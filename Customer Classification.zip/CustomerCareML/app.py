import streamlit as st
import pandas as pd
import joblib
import os
from datetime import datetime
import psycopg2
from psycopg2.extras import RealDictCursor
import json
from google import genai

# Using Google Gemini API - the newest model is "gemini-2.5-flash"
# do not change this unless explicitly requested by the user

MODEL_PATH = "attached_assets/xgboost_telecom_pipeline_1764409717513.joblib"
DATA_PATH = "attached_assets/telecom_customers_synthetic_balanced_download_1764409721205.csv"

DEFAULT_TEMPLATES = {
    'premium': """Dear {first_name},

Thank you for being a valued customer with us for {tenure_days} days. We truly appreciate your loyalty and excellent payment history.

This is a friendly reminder that your account shows a balance of ${overdue_amount:.2f}. Your next payment is due on {due_date}.

If you have any questions, please contact us at {support_number}.

Thank you for choosing our services.

Best regards,
Customer Care Team""",

    'normal': """Dear {first_name},

We hope this message finds you well. This is a reminder regarding your account status.

Your current outstanding balance is ${overdue_amount:.2f}, due on {due_date}. To avoid any service interruption (suspension date: {suspension_date}), please ensure timely payment.

For payment assistance or questions, call us at {support_number}.

Thank you for your attention to this matter.

Best regards,
Customer Care Team""",

    'defector': """Dear {first_name},

URGENT PAYMENT REMINDER

We've noticed your account requires immediate attention. Your outstanding balance of ${overdue_amount:.2f} is overdue, with {num_late_payments} late payments in the past 12 months.

To prevent service suspension on {suspension_date}, please make a payment as soon as possible. We understand circumstances can be challenging, and we're here to help.

Payment plan options are available. Please call us immediately at {support_number} to discuss your options.

We value you as a customer and want to help resolve this matter.

Sincerely,
Customer Care Team"""
}

def get_db_connection():
    """Get database connection"""
    try:
        conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
        return conn
    except Exception as e:
        st.warning(f"Database connection issue: {e}")
        return None

def init_database():
    """Initialize database tables"""
    conn = get_db_connection()
    if conn is None:
        return False
    
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS message_history (
                    id SERIAL PRIMARY KEY,
                    customer_id VARCHAR(50) NOT NULL,
                    customer_name VARCHAR(100),
                    classification VARCHAR(20),
                    message TEXT,
                    template_used VARCHAR(20),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            cur.execute("""
                CREATE TABLE IF NOT EXISTS message_templates (
                    id SERIAL PRIMARY KEY,
                    category VARCHAR(20) UNIQUE NOT NULL,
                    template TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            for category, template in DEFAULT_TEMPLATES.items():
                cur.execute("""
                    INSERT INTO message_templates (category, template)
                    VALUES (%s, %s)
                    ON CONFLICT (category) DO NOTHING
                """, (category, template))
            
            conn.commit()
        return True
    except Exception as e:
        st.error(f"Database initialization error: {e}")
        return False
    finally:
        conn.close()

def save_message_to_history(customer_id, customer_name, classification, message, template_used="llm"):
    """Save generated message to history"""
    conn = get_db_connection()
    if conn is None:
        return False
    
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO message_history (customer_id, customer_name, classification, message, template_used)
                VALUES (%s, %s, %s, %s, %s)
            """, (customer_id, customer_name, classification, message, template_used))
            conn.commit()
        return True
    except Exception as e:
        return False
    finally:
        conn.close()

def get_message_history(limit=100):
    """Get message history from database"""
    conn = get_db_connection()
    if conn is None:
        return []
    
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT * FROM message_history 
                ORDER BY created_at DESC 
                LIMIT %s
            """, (limit,))
            return cur.fetchall()
    except Exception as e:
        return []
    finally:
        conn.close()

def get_template(category):
    """Get message template for a category"""
    conn = get_db_connection()
    if conn is None:
        return DEFAULT_TEMPLATES.get(category, DEFAULT_TEMPLATES['normal'])
    
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT template FROM message_templates WHERE category = %s", (category,))
            result = cur.fetchone()
            if result:
                return result['template']
            return DEFAULT_TEMPLATES.get(category, DEFAULT_TEMPLATES['normal'])
    except Exception as e:
        return DEFAULT_TEMPLATES.get(category, DEFAULT_TEMPLATES['normal'])
    finally:
        conn.close()

def save_template(category, template):
    """Save or update a message template"""
    conn = get_db_connection()
    if conn is None:
        return False
    
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO message_templates (category, template, updated_at)
                VALUES (%s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (category) DO UPDATE SET template = %s, updated_at = CURRENT_TIMESTAMP
            """, (category, template, template))
            conn.commit()
        return True
    except Exception as e:
        return False
    finally:
        conn.close()

def get_analytics_data():
    """Get analytics data for dashboard"""
    conn = get_db_connection()
    if conn is None:
        return None
    
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT 
                    classification,
                    COUNT(*) as count,
                    template_used,
                    DATE(created_at) as date
                FROM message_history
                GROUP BY classification, template_used, DATE(created_at)
                ORDER BY date DESC
            """)
            return cur.fetchall()
    except Exception as e:
        return None
    finally:
        conn.close()

@st.cache_resource
def load_model():
    """Load the XGBoost model pipeline"""
    try:
        model = joblib.load(MODEL_PATH)
        return model, None
    except Exception as e:
        return None, str(e)

@st.cache_data
def load_customer_data():
    """Load customer data from CSV"""
    try:
        df = pd.read_csv(DATA_PATH)
        return df
    except Exception as e:
        st.error(f"Error loading customer data: {e}")
        return None

def get_customer_info(df, customer_id):
    """Get customer information by ID"""
    customer = df[df['customer_id'] == customer_id]
    if customer.empty:
        return None
    return customer.iloc[0]

def classify_customer(model, customer_data):
    """Classify customer using the ML model"""
    feature_columns = [
        'has_auto_pay', 'is_on_promotion', 'num_products', 'tenure_days',
        'ARPU', 'avg_monthly_spend_6m', 'total_data_MB_30d', 'total_minutes_30d',
        'num_late_payments_12m', 'payment_delay_days_mean_12m', 'days_since_last_payment',
        'overdue_amount', 'complaint_last_6m', 'downgrade_in_last_90d', 'support_calls_3m',
        'recent_topup_amount'
    ]
    
    try:
        features = customer_data[feature_columns].values.reshape(1, -1)
        prediction = model.predict(features)
        
        if hasattr(model, 'predict_proba'):
            proba = model.predict_proba(features)
            return prediction[0], proba[0]
        return prediction[0], None
    except Exception as e:
        label = customer_data.get('label', 'normal')
        return label, None

def generate_template_message(customer_info, classification):
    """Generate message using template"""
    template = get_template(classification)
    
    first_name = customer_info['name'].split('_')[0]
    
    try:
        message = template.format(
            first_name=first_name,
            name=customer_info['name'],
            tenure_days=customer_info['tenure_days'],
            overdue_amount=customer_info['overdue_amount'],
            due_date=customer_info['due_date'],
            suspension_date=customer_info['suspension_date'],
            support_number=customer_info['support_number'],
            num_late_payments=customer_info['num_late_payments_12m'],
            region=customer_info['region'],
            contract_type=customer_info['contract_type']
        )
        return message
    except Exception as e:
        return f"Error generating message from template: {str(e)}"

def generate_llm_message(customer_info, classification):
    """Generate personalized repayment message using Google Gemini"""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return "Gemini API key not configured. Please add your GEMINI_API_KEY to use AI message generation."
    
    client = genai.Client(api_key=api_key)
    
    customer_context = f"""
    Customer Name: {customer_info['name']}
    Classification: {classification}
    Contract Type: {customer_info['contract_type']}
    Region: {customer_info['region']}
    Contact Preference: {customer_info['contact_pref']}
    Tenure: {customer_info['tenure_days']} days
    Overdue Amount: ${customer_info['overdue_amount']:.2f}
    Number of Late Payments (12 months): {customer_info['num_late_payments_12m']}
    Average Payment Delay: {customer_info['payment_delay_days_mean_12m']:.1f} days
    Days Since Last Payment: {customer_info['days_since_last_payment']}
    Due Date: {customer_info['due_date']}
    Suspension Date: {customer_info['suspension_date']}
    Has Auto Pay: {'Yes' if customer_info['has_auto_pay'] else 'No'}
    Support Number: {customer_info['support_number']}
    """
    
    tone_guidance = {
        'premium': "Use an appreciative and respectful tone. Thank them for being a valued customer. Gently remind about any pending payments.",
        'normal': "Use a friendly and professional tone. Provide clear information about their payment status and options.",
        'defector': "Use an urgent but understanding tone. Emphasize the importance of timely payment to avoid service disruption. Offer support and payment plan options."
    }
    
    prompt = f"""You are a customer service representative for a telecom company. Generate a personalized repayment reminder message for this customer.

Customer Information:
{customer_context}

Tone Guidance: {tone_guidance.get(classification, tone_guidance['normal'])}

Requirements:
1. Address the customer by their first name (extract from the name field)
2. Be concise but warm
3. Mention the specific overdue amount if greater than 0
4. Include the due date and suspension date if relevant
5. Provide the support number for assistance
6. Keep the message under 200 words
7. Do not include placeholder brackets or template variables

Generate the message:"""

    try:
        # Using Gemini 2.5 Flash - the newest model
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        return response.text or "Error: Empty response from AI"
    except Exception as e:
        return f"Error generating message: {str(e)}"

def display_customer_result(customer_info, classification, message, model):
    """Display single customer classification result"""
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Customer Information**")
        info_data = {
            "Name": customer_info['name'],
            "Region": customer_info['region'],
            "Contract Type": customer_info['contract_type'],
            "Tenure": f"{customer_info['tenure_days']} days"
        }
        for key, value in info_data.items():
            st.markdown(f"- {key}: {value}")
    
    with col2:
        st.markdown("**Payment Status**")
        payment_data = {
            "Overdue Amount": f"${customer_info['overdue_amount']:.2f}",
            "Late Payments": customer_info['num_late_payments_12m'],
            "Risk Score": f"{customer_info['risk_score']:.4f}"
        }
        for key, value in payment_data.items():
            st.markdown(f"- {key}: {value}")
    
    label_colors = {
        'premium': '#d4edda',
        'normal': '#cce5ff',
        'defector': '#f8d7da'
    }
    
    st.markdown(f"""
    <div style="padding: 10px; border-radius: 5px; background-color: {label_colors.get(classification, '#f8f9fa')}; margin: 10px 0;">
        <strong>Classification: {classification.upper()}</strong>
    </div>
    """, unsafe_allow_html=True)
    
    with st.expander("View Generated Message"):
        st.text(message)

def single_customer_page():
    """Single customer classification page"""
    st.header("Single Customer Classification")
    st.markdown("Enter a customer ID to classify them and generate a personalized repayment message.")
    
    model, model_error = load_model()
    df = load_customer_data()
    
    if df is None:
        st.error("Failed to load customer data.")
        return
    
    if model is None and model_error:
        st.warning(f"ML model could not be loaded (using CSV labels as fallback): {model_error}")
    
    sample_ids = df['customer_id'].head(10).tolist()
    with st.expander("Sample Customer IDs"):
        st.code("\n".join(sample_ids))
    
    col1, col2 = st.columns([3, 1])
    with col1:
        customer_id = st.text_input("Enter Customer ID:", placeholder="e.g., CUST00398")
    with col2:
        message_type = st.selectbox("Message Type:", ["LLM Generated", "Template Based"])
    
    if st.button("Classify & Generate Message", type="primary"):
        if not customer_id:
            st.warning("Please enter a customer ID.")
            return
        
        customer_info = get_customer_info(df, customer_id)
        
        if customer_info is None:
            st.error(f"Customer ID '{customer_id}' not found.")
            return
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Customer Information")
            info_data = {
                "Name": customer_info['name'],
                "Region": customer_info['region'],
                "Contract Type": customer_info['contract_type'],
                "Contact Preference": customer_info['contact_pref'],
                "Tenure": f"{customer_info['tenure_days']} days",
                "Number of Products": customer_info['num_products'],
                "Has Auto Pay": "Yes" if customer_info['has_auto_pay'] else "No",
                "On Promotion": "Yes" if customer_info['is_on_promotion'] else "No"
            }
            for key, value in info_data.items():
                st.markdown(f"**{key}:** {value}")
        
        with col2:
            st.subheader("Payment Status")
            payment_data = {
                "Overdue Amount": f"${customer_info['overdue_amount']:.2f}",
                "Late Payments (12 months)": customer_info['num_late_payments_12m'],
                "Avg Payment Delay": f"{customer_info['payment_delay_days_mean_12m']:.1f} days",
                "Days Since Last Payment": customer_info['days_since_last_payment'],
                "Due Date": customer_info['due_date'],
                "Suspension Date": customer_info['suspension_date'],
                "Risk Score": f"{customer_info['risk_score']:.4f}"
            }
            for key, value in payment_data.items():
                st.markdown(f"**{key}:** {value}")
        
        st.divider()
        st.subheader("Classification Result")
        
        if model is not None:
            with st.spinner("Classifying customer..."):
                classification, _ = classify_customer(model, customer_info)
        else:
            st.info("Using pre-labeled classification from data (ML model not available)")
            classification = customer_info['label']
        
        label_colors = {
            'premium': ('#d4edda', '#155724', '#28a745'),
            'normal': ('#cce5ff', '#004085', '#007bff'),
            'defector': ('#f8d7da', '#721c24', '#dc3545')
        }
        
        bg, text, border = label_colors.get(classification, ('#f8f9fa', '#333', '#ccc'))
        
        descriptions = {
            'premium': 'Valued customer with excellent payment history',
            'normal': 'Regular customer with standard payment behavior',
            'defector': 'At-risk customer requiring immediate attention'
        }
        
        st.markdown(f"""
        <div style="padding: 20px; border-radius: 10px; background-color: {bg}; border: 1px solid {border};">
            <h3 style="color: {text}; margin: 0;">Classification: {classification.upper()}</h3>
            <p style="color: {text}; margin-top: 10px;">{descriptions.get(classification, '')}</p>
        </div>
        """, unsafe_allow_html=True)
        
        st.divider()
        st.subheader("Generated Repayment Message")
        
        template_type = "llm" if message_type == "LLM Generated" else "template"
        
        with st.spinner("Generating message..."):
            if message_type == "LLM Generated":
                message = generate_llm_message(customer_info, classification)
            else:
                message = generate_template_message(customer_info, classification)
        
        st.markdown(f"""
        <div style="padding: 20px; border-radius: 10px; background-color: #e8f4f8; border: 2px solid #0288d1; color: #01579b;">
            <p style="white-space: pre-wrap; font-family: Arial, sans-serif; line-height: 1.6; color: #01579b; margin: 0;">{message}</p>
        </div>
        """, unsafe_allow_html=True)
        
        save_message_to_history(customer_id, customer_info['name'], classification, message, template_type)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.download_button(
                label="📥 Download Message",
                data=str(message),
                file_name=f"message_{customer_id}.txt",
                mime="text/plain"
            )
        with col2:
            if st.button("📧 Send Email", key=f"email_{customer_id}"):
                st.info(f"Email sending feature would send to: {customer_info['name']}\n\nTo enable this, connect your email service (SendGrid, Gmail, or Resend).")
        with col3:
            if st.button("📱 Send SMS", key=f"sms_{customer_id}"):
                st.info(f"SMS sending feature would send to customer.\n\nTo enable this, connect Twilio for SMS services.")

def bulk_processing_page():
    """Bulk customer processing page"""
    st.header("Bulk Customer Processing")
    st.markdown("Process multiple customers at once. Enter customer IDs separated by commas or newlines.")
    
    model, model_error = load_model()
    df = load_customer_data()
    
    if df is None:
        st.error("Failed to load customer data.")
        return
    
    if model is None and model_error:
        st.warning(f"ML model could not be loaded (using CSV labels as fallback): {model_error}")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        customer_ids_input = st.text_area(
            "Enter Customer IDs (comma or newline separated):",
            placeholder="CUST00398, CUST01529, CUST01887\nor\nCUST00398\nCUST01529\nCUST01887",
            height=150
        )
    
    with col2:
        message_type = st.selectbox("Message Type:", ["Template Based", "LLM Generated"], key="bulk_msg_type")
        st.info("Template-based messages are faster for bulk processing.")
        
        sample_ids = df['customer_id'].head(5).tolist()
        st.markdown("**Sample IDs:**")
        st.code("\n".join(sample_ids))
    
    if st.button("Process All Customers", type="primary"):
        if not customer_ids_input.strip():
            st.warning("Please enter at least one customer ID.")
            return
        
        customer_ids = [id.strip() for id in customer_ids_input.replace('\n', ',').split(',') if id.strip()]
        
        st.info(f"Processing {len(customer_ids)} customers...")
        
        results = []
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        for i, cust_id in enumerate(customer_ids):
            status_text.text(f"Processing {cust_id}...")
            
            customer_info = get_customer_info(df, cust_id)
            
            if customer_info is None:
                results.append({
                    'customer_id': cust_id,
                    'status': 'Not Found',
                    'classification': '-',
                    'message': 'Customer not found in database'
                })
            else:
                if model is not None:
                    classification, _ = classify_customer(model, customer_info)
                else:
                    classification = customer_info['label']
                
                if message_type == "LLM Generated":
                    message = generate_llm_message(customer_info, classification)
                    template_type = "llm"
                else:
                    message = generate_template_message(customer_info, classification)
                    template_type = "template"
                
                save_message_to_history(cust_id, customer_info['name'], classification, message, template_type)
                
                results.append({
                    'customer_id': cust_id,
                    'name': customer_info['name'],
                    'status': 'Processed',
                    'classification': classification,
                    'overdue_amount': customer_info['overdue_amount'],
                    'risk_score': customer_info['risk_score'],
                    'message': message
                })
            
            progress_bar.progress((i + 1) / len(customer_ids))
        
        status_text.text("Processing complete!")
        
        st.subheader("Results Summary")
        
        processed = [r for r in results if r['status'] == 'Processed']
        not_found = [r for r in results if r['status'] == 'Not Found']
        
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Processed", len(processed))
        col2.metric("Not Found", len(not_found))
        
        if processed:
            premium_count = len([r for r in processed if r['classification'] == 'premium'])
            normal_count = len([r for r in processed if r['classification'] == 'normal'])
            defector_count = len([r for r in processed if r['classification'] == 'defector'])
            col3.metric("Premium", premium_count)
            col4.metric("Defectors", defector_count)
        
        st.divider()
        
        for result in results:
            with st.expander(f"{result['customer_id']} - {result['status']} - {result['classification'].upper()}"):
                if result['status'] == 'Processed':
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown(f"**Name:** {result['name']}")
                        st.markdown(f"**Classification:** {result['classification'].upper()}")
                    with col2:
                        st.markdown(f"**Overdue:** ${result['overdue_amount']:.2f}")
                        st.markdown(f"**Risk Score:** {result['risk_score']:.4f}")
                    st.markdown("**Message:**")
                    st.text(result['message'])
                else:
                    st.warning(result['message'])
        
        results_df = pd.DataFrame([{
            'Customer ID': r['customer_id'],
            'Name': r.get('name', '-'),
            'Status': r['status'],
            'Classification': r['classification'],
            'Overdue Amount': r.get('overdue_amount', '-'),
            'Message': r['message']
        } for r in results])
        
        csv_data = results_df.to_csv(index=False)
        st.download_button(
            label="Download Results (CSV)",
            data=csv_data,
            file_name=f"bulk_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

def template_customization_page():
    """Message template customization page"""
    st.header("Message Template Customization")
    st.markdown("Customize message templates for each customer classification category.")
    
    st.info("""
    **Available placeholders:**
    - `{first_name}` - Customer's first name
    - `{name}` - Full name
    - `{tenure_days}` - Customer tenure in days
    - `{overdue_amount}` - Overdue amount (use `{overdue_amount:.2f}` for 2 decimal places)
    - `{due_date}` - Payment due date
    - `{suspension_date}` - Service suspension date
    - `{support_number}` - Customer support number
    - `{num_late_payments}` - Number of late payments
    - `{region}` - Customer region
    - `{contract_type}` - Contract type
    """)
    
    category = st.selectbox("Select Category:", ["premium", "normal", "defector"])
    
    current_template = get_template(category)
    
    new_template = st.text_area(
        f"Edit {category.upper()} Template:",
        value=current_template,
        height=300
    )
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Save Template", type="primary"):
            if save_template(category, new_template):
                st.success(f"Template for {category.upper()} saved successfully!")
            else:
                st.error("Failed to save template. Please try again.")
    
    with col2:
        if st.button("Reset to Default"):
            if save_template(category, DEFAULT_TEMPLATES[category]):
                st.success(f"Template for {category.upper()} reset to default!")
                st.rerun()
    
    st.divider()
    st.subheader("Preview")
    
    preview_data = {
        'first_name': 'John',
        'name': 'John_123',
        'tenure_days': 365,
        'overdue_amount': 150.50,
        'due_date': '2025-12-15',
        'suspension_date': '2025-12-25',
        'support_number': '1800-222-333',
        'num_late_payments': 2,
        'region': 'Central',
        'contract_type': 'postpaid'
    }
    
    try:
        preview_message = new_template.format(**preview_data)
        st.markdown(f"""
        <div style="padding: 20px; border-radius: 10px; background-color: #f8f9fa; border: 1px solid #dee2e6;">
            <p style="white-space: pre-wrap; font-family: Arial, sans-serif; line-height: 1.6;">{preview_message}</p>
        </div>
        """, unsafe_allow_html=True)
    except Exception as e:
        st.error(f"Template error: {str(e)}")

def message_history_page():
    """Message history page"""
    st.header("Message History")
    st.markdown("View and export previously generated messages.")
    
    history = get_message_history(limit=200)
    
    if not history:
        st.info("No messages generated yet. Start by classifying customers on the Single Customer or Bulk Processing pages.")
        return
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        filter_classification = st.selectbox(
            "Filter by Classification:",
            ["All", "premium", "normal", "defector"]
        )
    
    with col2:
        filter_template = st.selectbox(
            "Filter by Message Type:",
            ["All", "llm", "template"]
        )
    
    filtered_history = history
    if filter_classification != "All":
        filtered_history = [h for h in filtered_history if h['classification'] == filter_classification]
    if filter_template != "All":
        filtered_history = [h for h in filtered_history if h['template_used'] == filter_template]
    
    st.markdown(f"**Showing {len(filtered_history)} messages**")
    
    if filtered_history:
        history_df = pd.DataFrame([{
            'Customer ID': h['customer_id'],
            'Name': h['customer_name'],
            'Classification': h['classification'],
            'Type': h['template_used'],
            'Date': h['created_at'].strftime('%Y-%m-%d %H:%M') if h['created_at'] else '-',
            'Message': h['message'][:100] + '...' if len(h['message']) > 100 else h['message']
        } for h in filtered_history])
        
        st.dataframe(history_df, use_container_width=True)
        
        full_export_df = pd.DataFrame([{
            'Customer ID': h['customer_id'],
            'Customer Name': h['customer_name'],
            'Classification': h['classification'],
            'Message Type': h['template_used'],
            'Created At': h['created_at'].strftime('%Y-%m-%d %H:%M:%S') if h['created_at'] else '-',
            'Message': h['message']
        } for h in filtered_history])
        
        csv_data = full_export_df.to_csv(index=False)
        st.download_button(
            label="Export to CSV",
            data=csv_data,
            file_name=f"message_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        st.divider()
        st.subheader("Message Details")
        
        for h in filtered_history[:20]:
            with st.expander(f"{h['customer_id']} - {h['customer_name']} ({h['classification'].upper()})"):
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown(f"**Classification:** {h['classification'].upper()}")
                    st.markdown(f"**Message Type:** {h['template_used']}")
                with col2:
                    st.markdown(f"**Created:** {h['created_at'].strftime('%Y-%m-%d %H:%M') if h['created_at'] else '-'}")
                st.markdown("**Message:**")
                st.text(h['message'])

def analytics_dashboard_page():
    """Analytics dashboard page"""
    st.header("Analytics Dashboard")
    st.markdown("View classification distribution and messaging statistics.")
    
    history = get_message_history(limit=1000)
    
    if not history:
        st.info("No data available yet. Start by classifying customers to see analytics.")
        return
    
    col1, col2, col3, col4 = st.columns(4)
    
    premium_count = len([h for h in history if h['classification'] == 'premium'])
    normal_count = len([h for h in history if h['classification'] == 'normal'])
    defector_count = len([h for h in history if h['classification'] == 'defector'])
    
    col1.metric("Total Messages", len(history))
    col2.metric("Premium Customers", premium_count)
    col3.metric("Normal Customers", normal_count)
    col4.metric("At-Risk (Defectors)", defector_count)
    
    st.divider()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Classification Distribution")
        
        class_data = pd.DataFrame({
            'Classification': ['Premium', 'Normal', 'Defector'],
            'Count': [premium_count, normal_count, defector_count]
        })
        
        st.bar_chart(class_data.set_index('Classification'))
    
    with col2:
        st.subheader("Message Type Distribution")
        
        llm_count = len([h for h in history if h['template_used'] == 'llm'])
        template_count = len([h for h in history if h['template_used'] == 'template'])
        
        type_data = pd.DataFrame({
            'Type': ['LLM Generated', 'Template Based'],
            'Count': [llm_count, template_count]
        })
        
        st.bar_chart(type_data.set_index('Type'))
    
    st.divider()
    st.subheader("Recent Activity")
    
    df_history = pd.DataFrame(history)
    if 'created_at' in df_history.columns and not df_history.empty:
        df_history['date'] = pd.to_datetime(df_history['created_at']).dt.date
        daily_counts = df_history.groupby('date', as_index=False).size()
        daily_counts.columns = ['date', 'count']
        daily_counts = daily_counts.sort_values('date')
        
        if len(daily_counts) > 1:
            st.line_chart(daily_counts.set_index('date')['count'])
        else:
            st.info("More data needed for trend analysis.")
    
    st.divider()
    st.subheader("Classification by Message Type")
    
    cross_tab = pd.DataFrame([
        {'Classification': 'Premium', 'LLM': len([h for h in history if h['classification'] == 'premium' and h['template_used'] == 'llm']),
         'Template': len([h for h in history if h['classification'] == 'premium' and h['template_used'] == 'template'])},
        {'Classification': 'Normal', 'LLM': len([h for h in history if h['classification'] == 'normal' and h['template_used'] == 'llm']),
         'Template': len([h for h in history if h['classification'] == 'normal' and h['template_used'] == 'template'])},
        {'Classification': 'Defector', 'LLM': len([h for h in history if h['classification'] == 'defector' and h['template_used'] == 'llm']),
         'Template': len([h for h in history if h['classification'] == 'defector' and h['template_used'] == 'template'])}
    ])
    
    st.dataframe(cross_tab.set_index('Classification'), use_container_width=True)

def main():
    st.set_page_config(
        page_title="Customer Classification & Messaging",
        page_icon="📊",
        layout="wide"
    )
    
    init_database()
    
    st.sidebar.title("Navigation")
    page = st.sidebar.radio(
        "Select Page:",
        ["Single Customer", "Bulk Processing", "Message Templates", "Message History", "Analytics"]
    )
    
    st.sidebar.divider()
    st.sidebar.markdown("**Quick Stats**")
    
    history = get_message_history(limit=1000)
    if history:
        st.sidebar.metric("Total Messages", len(history))
        defector_count = len([h for h in history if h['classification'] == 'defector'])
        st.sidebar.metric("At-Risk Customers", defector_count)
    
    if page == "Single Customer":
        single_customer_page()
    elif page == "Bulk Processing":
        bulk_processing_page()
    elif page == "Message Templates":
        template_customization_page()
    elif page == "Message History":
        message_history_page()
    elif page == "Analytics":
        analytics_dashboard_page()

if __name__ == "__main__":
    main()

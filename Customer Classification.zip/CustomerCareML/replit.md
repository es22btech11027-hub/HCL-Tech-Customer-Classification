# Customer Classification & Repayment Messaging System

## Overview
A Streamlit web application that classifies telecom customers using a pre-trained XGBoost model and generates personalized repayment messages using either LLM (OpenAI GPT-5) or customizable templates.

## Features

### MVP Features
- **Single Customer Classification**: Enter a customer ID to classify them and generate personalized repayment messages
- **XGBoost Model Integration**: Uses pre-trained model from joblib file for customer risk classification (premium, normal, defector)
- **Customer Data Display**: Shows customer information, payment status, and risk metrics
- **LLM Message Generation**: Uses OpenAI GPT-5 for personalized message generation
- **Template-Based Messages**: Faster alternative using customizable templates

### Enhanced Features
- **Bulk Processing**: Process multiple customer IDs at once with batch classification and message generation
- **Message Templates**: Customize templates for each risk category with placeholder support
- **Message History**: Track all generated messages with PostgreSQL database storage
- **Export Functionality**: Download results as CSV files
- **Analytics Dashboard**: View classification distribution, message type statistics, and trends

## Project Structure
```
.
├── app.py                    # Main Streamlit application
├── attached_assets/
│   ├── xgboost_telecom_pipeline_1764409717513.joblib  # Pre-trained ML model
│   └── telecom_customers_synthetic_balanced_download_1764409721205.csv  # Customer data
├── .streamlit/
│   └── config.toml          # Streamlit configuration
├── pyproject.toml           # Python dependencies
└── replit.md                # This file
```

## Database Schema (PostgreSQL)

### message_history
- `id`: Serial primary key
- `customer_id`: Customer identifier
- `customer_name`: Customer name
- `classification`: Risk category (premium/normal/defector)
- `message`: Generated message content
- `template_used`: Message type (llm/template)
- `created_at`: Timestamp

### message_templates
- `id`: Serial primary key
- `category`: Risk category
- `template`: Template text with placeholders
- `updated_at`: Last modification timestamp

## Template Placeholders
Available placeholders for message templates:
- `{first_name}` - Customer's first name
- `{name}` - Full name
- `{tenure_days}` - Customer tenure in days
- `{overdue_amount}` - Overdue amount (use `{overdue_amount:.2f}`)
- `{due_date}` - Payment due date
- `{suspension_date}` - Service suspension date
- `{support_number}` - Customer support number
- `{num_late_payments}` - Number of late payments
- `{region}` - Customer region
- `{contract_type}` - Contract type

## Customer Classification Labels
- **Premium**: Valued customer with excellent payment history
- **Normal**: Regular customer with standard payment behavior
- **Defector**: At-risk customer requiring immediate attention

## Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string (auto-configured)
- `OPENAI_API_KEY`: OpenAI API key for LLM message generation

## Running the Application
```bash
streamlit run app.py --server.port 5000
```

## Recent Changes
- 2025-11-29: Initial MVP with single customer classification
- 2025-11-29: Added bulk processing, message templates, history tracking, and analytics dashboard
